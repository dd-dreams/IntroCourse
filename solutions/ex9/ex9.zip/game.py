from helper import load_json
import board
import car
from sys import argv


# ----Basic assignments---- #
CAR_COLORS = ['Y', 'B', 'O', 'W', 'G', 'R']
LEN_BOARD = 7

# ----Messages---- #
WELCOME_MESSAGE = "Welcome! This is a Rush-Hour game!\n"
INSTRUCTIONS = """
Your goal is to get to the exit point (E), with whatever car you want,
as long the car is horizontal.
Enjoy!!!!
"""
INPUT_MESSAGE = "Please input the car you want to move, and to which location (color, direction): "
INPUT_ERROR = "\nYou have input a wrong input. Please try again. "
CANT_USE_DIRECTION = "\nYou can't use that direction. Try again."
PASS_BORDER_ERROR = "\nThe direction you chose for the car, passes the border. Try again."


def deep_copy_dictionary(dictionary):
    return {key: value for key, value in dictionary.items()}


def welcome_message():
    print(WELCOME_MESSAGE)
    print(INSTRUCTIONS)


class Game:
    def __init__(self, cars, length):
        self.__len_board = length
        self.__board = board.Board(TEMPLATE, self.generate_coordinates(), self.__len_board,
                                   CARS)
        self.__square = '_'
        self.__end_line_char = '*'
        self.__cars = cars
        self.__template = self.__board.json_template()
        self.__cars_coordinates = deep_copy_dictionary(TEMPLATE)
        self.__input = None
        self.__directions = ['U', 'D', 'R', 'L']

    def generate_coordinates(self):
        """
        this method will generate all the coordinates-
        available in a specific range.
        :return: generated coordinates
        """
        coordinates = []
        for row in range(self.__len_board):
            for col in range(self.__len_board):
                coordinates.append([row, col])
        return coordinates

    def check_input(self, direction):
        """
        this method will check the input.
        1 is for "move car to the right", 2 is for "move car to the left",
        3 is for "move car up", 4 is for "move car down", 5 if for "error", 6 is for "end the game",
        :return: an int which will decide what to do
        """
        option = 0
        if self.__input[0].isalpha() and self.__input[1] == ',' \
                and self.__input[2].isalpha() and len(self.__input) == 3:
            if direction == 'R':
                option = 1
            elif direction == 'L':
                option = 2
            elif direction == 'U':
                option = 3
            elif direction == 'D':
                option = 4
        else:
            option = 5
        return option

    def update_cars_coordinates(self, color, coordinates):
        """
        this method will update the current spot of the car that just moved.
        :param color: which color to update his coordinates
        :param coordinates: with what coordinates to update
        :return:
        """
        car_len, spot, direction = self.__cars.generate_car_config(
            self.__cars_coordinates[color])
        self.__cars_coordinates[color] = [car_len, coordinates[0], direction]

    def divide_input(self):
        """
        this method divides the input between the color, and direction
        :return: color, direction
        """
        color_input, direction_input = self.__input.split(',')
        return color_input, direction_input

    def print_board(self):
        """
        just prints the board
        :return:
        """
        temp_board = self.__board.get_template()
        print()
        for row in temp_board:
            final = ""
            for col in row:
                final += col
            print(final)

    def directions(self, color, direct_up_down, direct_right_left):
        """

        :param color: the car to move
        :param direct_up_down: decides whether the car is moving up or down (look check_if_car_on_car API)
        :param direct_right_left: decides whether the car is moving right or left         ^
        :return: if the game end or not
        """
        car_len, spot, direction = CARS.generate_car_config(
            self.__cars_coordinates[color])
        # checks if he wanted to use up/down-wards direction for a car that is 1 (horizontal)
        if direction == 1 and direct_up_down != 0:
            return print(CANT_USE_DIRECTION)
        # checks if he wanted to use right/left direction for a car that is 0 (vertical)
        elif direction == 0 and direct_right_left != 0:
            return print(CANT_USE_DIRECTION)
        coors_of_car = self.__board.coordinates_from_spot_in_length(
            car_len, spot, direction)
        # making new coordinates of the car according to the input
        new_coors_of_car = self.__board.coordinates_from_spot_in_length(car_len,
                                                                        [spot[0] - direct_up_down, spot[1] +
                                                                         direct_right_left], direction)
        # checking if the car passes the border
        if new_coors_of_car is None:
            return print(PASS_BORDER_ERROR)
        if direct_right_left == -1:
            forward_back = direct_right_left
        else:
            forward_back = direct_up_down
        # making sure a car is not on top of another car
        if not self.__board.check_if_car_on_car(color, forward_back, direction, CARS_VALID_COLORS,
                                                self.__cars_coordinates):
            return print(CANT_USE_DIRECTION)
        # checks if the new coordinates of the car pass or fill the border
        if not CARS.exceptions_car((car_len, new_coors_of_car[0], direction)):
            return print(PASS_BORDER_ERROR)
        # editing the template according to the coordinates
        self.__board.edit_template(color, new_coors_of_car, coors_of_car)
        # setting the new template after editing
        self.__template = self.__board.get_template()
        self.update_cars_coordinates(color, new_coors_of_car)
        if self.check_win(new_coors_of_car):
            return True
        return False

    def check_win(self, coordinates):
        for coordinate in coordinates:
            if coordinate == [3, 6]:
                print("\nYou won! Good game :)")
                return True
        return False

    def get_input(self):
        """
        this method will take and input, and handle it.
        it will check the color and direction, and decide what to do.
        :return:
        """
        welcome_message()
        self.print_board()
        while True:
            end = False  # if the game end or not
            self.__input = input(INPUT_MESSAGE).upper()
            # checking if the input is wrong
            option = self.check_input(self.__input[-1])
            # checking if he wanted to end the game
            if self.__input != '!' and option == 5:
                print(INPUT_ERROR)
                self.print_board()
                continue
            if self.__input == '!':  # checking if he wanted to end the game
                break
            color_input, direction_input = self.divide_input()
            if option == 1:  # right direction
                end = self.directions(color_input, 0, 1)
            elif option == 2:  # left direction
                end = self.directions(color_input, 0, -1)
            elif option == 3:
                end = self.directions(color_input, 1, 0)
            elif option == 4:
                end = self.directions(color_input, -1, 0)
            else:
                print(INPUT_ERROR)
            self.print_board()
            if end:
                return


if __name__ == '__main__':
    json = argv[1]
    TEMPLATE = load_json(json)
    if not TEMPLATE:
        print("JSON file not found.")
    else:
        CARS = car.Car(CAR_COLORS, LEN_BOARD, TEMPLATE)
        CARS_VALID_COLORS = CARS.check_file_colors()
        game = Game(CARS, LEN_BOARD)
        game.get_input()
